﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BlueBasketTrigger : MonoBehaviour
{
    public Text bluetext;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("BlueBall"))
        {
            bluetext.text = "Blue ball placed correctly!";
        }
    }
}
