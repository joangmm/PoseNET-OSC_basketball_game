﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public Text winText;
    public Text bt;
    public Text gt;
    public Text ot;

    string aux_o;
    string aux_g;
    string aux_b;

    private string d_bt, d_gt, d_ot;
    void Start()
    {
        d_bt = "Blue ball placed correctly!";
        d_ot = "Orange ball placed correctly!";
        d_gt = "Green ball placed correctly!";
    }
    void Update()
    {
        aux_o = ot.text;
        aux_g = gt.text;
        aux_b = bt.text;
        if (AreEqual(aux_b, d_bt) && AreEqual(aux_o, d_ot) && AreEqual(aux_g, d_gt))
        {
            winText.text = "You win!!!";
        }

        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }
        else if (Input.GetKey(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }



    }
    private bool AreEqual(string val1, string val2)
    {
        if (val1.Length != val2.Length)
            return false;

        for (int i = 0; i < val1.Length; i++)
        {
            var c1 = val1[i];
            var c2 = val2[i];
            if (c1 != c2)
                return false;
        }

        return true;
    }
}
