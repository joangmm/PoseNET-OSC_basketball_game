﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OrangeBasketTrigger : MonoBehaviour
{
    public Text orangetext;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("OrangeBall"))
        {
            orangetext.text = "Orange ball placed correctly!";
        }
    }
}
